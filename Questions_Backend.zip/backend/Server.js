const express = require('express');
const app = express();
const cookieParser = require('cookie-parser');

app.use(cookieParser());

// ejs section
// app.use('/assets/css', express.static('assets/css'));
// app.set('view engine', 'ejs');

// convert json file using express
app.use(express.json());

// link router file(auth) from router folder
app.use(require("./router/auth"));

// backend page routing section
// app.get('/', function (req, res) {
//     db.query('SELECT * from UserData', (err, rows, fields) => {
//         if (!err) {
//             let data = rows;
//             res.render('pages/home', { data: data });
//         }
//         else {
//             console.log(err);
//         }
//     });
// });

// app.get('/about', function (req, res) {
//     res.render("pages/about");
// });

app.listen(5000, () => {
    console.log('Server is running on 5000 port.')
})