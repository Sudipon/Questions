const expressApp = require('express');
const dataapp = expressApp();
const mongooseApp = require('mongoose');
const Users=require('./sudipon01');
mongooseApp.connect('mongodb+srv://sudipon01:openbaby@01@cluster0.cpzn8.mongodb.net/userdata?retryWrites=true&w=majority',{
	useNewUrlParser : true,
	useUnifiedTopology : true}
).then(()=>{console.log("hii  ")})