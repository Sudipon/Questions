const mongooseApp=require('mongoose');

mongooseApp.connect('mongodb+srv://sudipon01:openbaby@01@cluster0.cpzn8.mongodb.net/userdata?retryWrites=true&w=majority',
    {useNewUrlParser : true,
    useUnifiedTopology : true}
).then(() => {
    console.log("MongoDB Connected Successfully.");
}).catch((err) => {
    console.log(err);
});

