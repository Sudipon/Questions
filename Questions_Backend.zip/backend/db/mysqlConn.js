var mysql = require('mysql')
var MsqConn = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'quora',
  multipleStatements: true
});

MsqConn.connect((err) => {
  if(!err){
    console.log('MySQL Connected Sucessfully.')
  }
  else{
    console.log(err)
  }
});

module.exports = MsqConn;